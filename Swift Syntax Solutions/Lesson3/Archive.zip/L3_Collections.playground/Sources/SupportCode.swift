//
// This file (and all other Swift source files in the Sources directory of this playground) will be precompiled into a framework which is automatically made available to Collections.playground.
//

public class LightSwitch {
    
    public var on: Bool = true
}

public var livingRoomSwitch = LightSwitch()
public var kitchenSwitch = LightSwitch()
public var bathroomSwitch = LightSwitch()